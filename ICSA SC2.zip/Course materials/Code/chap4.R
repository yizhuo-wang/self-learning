
#replace this directory with the one of the unzipped files
setwd("")

# install rmt package
install.packages("./Code/WR_0.2.0.tar.gz",repos = NULL, type = "source")
# or install the previous version from CRAN
# install.packages("WR")
library(WR)
# read in the data
data<-read.table("./Data/hf_action_nonisc.txt")
head(data)

# extract the variable for pwreg()
patid<-data$patid
time<-data$time
status<-data$status
Z<-as.matrix(data[,4:11])
Z.names<-c("Training vs Usual", "Age (decade)",
          "Male vs Female","CPX Duration", "CAN vs USA", "FRA vs USA",
          "Atrial Fibrillation","Diabetes")


# descriptive statistics
length(unique(patid)) # total sample size
length(unique(patid[Z[,"trt_ab"]==0])) # sample size for usual care
length(unique(patid[Z[,"trt_ab"]==1])) # sample size for exercise training

# fit PW model
obj<-pwreg(ID=patid, time=time,status=status,Z=Z)
obj

#joint test of study location
beta <- matrix(obj$beta[5:6])
#extract estimated covariance matrix for (\beta_4,\beta_5)
Sigma <- obj$Var[5:6,5:6]
#compute chisq statistic in quadratic form
chistats <- t(beta) %*% solve(Sigma) %*% beta  

#compare the Wald statistic with the reference
# distribution of chisq(2) to obtain the p-value
1 - pchisq(chistats, df=2)


# Compute the score processes
t=seq(1,48,by=1)
obj.score<-score.proc(obj,t)
# get the estimated scores
score<-obj.score$score
ts<-obj.score$t

# plot the score processes
par(mfrow=c(2,4))
par(mar = c(6, 2, 2, 2))

for (j in 1:8){
  xmax=48
  plot(c(0,ts),c(0,score[j,]),type='l',xlim=c(0,xmax), ylim=c(-3,3),yaxt="n",xaxt="n",
       lwd=3,main=Z.names[j],cex.main=1.3,cex.axis=1.3,xlab="Time (months)",
       ylab="Standardized score",cex.lab=1.3)
  axis(1, at=seq(0,48,by=12),seq(0,48,by=12),cex.axis=1.3)
  axis(2, at=c(-2,0,2),labels=c(-2,0,2),cex.axis=1.3)
  
  lines(c(0,xmax),c(0,0),lty=3,lwd=3,col="black")
  lines(c(0,xmax),c(2,2),lty=3,lwd=3,col="black")
  lines(c(0,xmax),c(-2,-2),lty=3,lwd=3,col="black")
}



### PS. Stratify by atrial fibrillation ###
Zs<-Z[,-7]
obj_str<-pwreg(ID=patid, time=time,status=status,Z=Zs,strata = Z[,7])
obj_str


