
#replace this directory with the one of the unzipped files
setwd("")


#Complile the source code for the function CompoML
source("./Code/CompoML/compute.txt")
source("./Code/CompoML/generic.txt")


library(survival)


# Read in the HF-ACTION data
data<-read.table("./Data/HF-ACTION.txt")

id<-data[,1]
time<-data[,2]
status<-data[,3]
Z<-as.matrix(data[,4:ncol(data)])
trt<-Z[,1]


# number of unique patients in total
n<-length(unique(id))

#number of patients in each arm
n1<-length(unique(id[trt==1&status<2]))
n0<-length(unique(id[trt==0&status<2]))

data[1:15,]

##TFE analysis ###

## Time to death ##
data.TD=data[data[,"status"]<2,]

pre.obj=summary(survfit(Surv(time, status) ~ Training, data=data.TD))

SD=pre.obj$surv
tD=pre.obj$time
trtD=pre.obj$strata

SD1=SD[trtD=="Training=1"]
tD1=tD[trtD=="Training=1"]

SD0=SD[trtD=="Training=0"]
tD0=tD[trtD=="Training=0"]

#log-rank test
survdiff(Surv(time, status) ~ Training, data=data.TD)


## Time to first event ####

## create dataset for TFE
## by taking the first record from each patient


#assuming data have been sorted by id and time
data.TFE = data[!duplicated(data[,"id"]),]
data.TFE[1:10,]

pre.obj=summary(survfit(Surv(time, status>0) ~ Training, data=data.TFE))

ST=pre.obj$surv
tT=pre.obj$time
trtT=pre.obj$strata

ST1=ST[trtT=="Training=1"]
tT1=tT[trtT=="Training=1"]

ST0=ST[trtT=="Training=0"]
tT0=tT[trtT=="Training=0"]

#log-rank test
survdiff(Surv(time, status>0) ~ Training, data=data.TFE)


#plot kaplan--Meier curves for death and TFE
{
par(mfrow=c(1,2))
#Training
#create a step function
x1=c(tD1[1],rep(tD1[2:length(tD1)],each=2))
y1=c(rep(SD1[1:(length(SD1)-1)],each=2),SD1[length(SD1)])
x1T=c(tT1[1],rep(tT1[2:length(tT1)],each=2))
y1T=c(rep(ST1[1:(length(ST1)-1)],each=2),ST1[length(ST1)])

plot(NULL,xlim=c(0,20),ylim=c(0,1),frame=F, xlab="Time (months)",
     ylab="Survival probabilities",main="Exercise Training")

polygon(c(x1,x1[length(x1)],0),c(y1,1,1),col='darkgray',border=F)
polygon(c(x1T,rev(x1),0),c(y1T,rev(y1),1),col='lightgray',border=F)
lines(x1,y1,lty=1)
lines(x1T,y1T,lty=3)
legend(0,0.2,lty=c(1,3),c("Death","TFE"))


#Usual Care
#create a step function
x0=c(tD0[1],rep(tD0[2:length(tD0)],each=2))
y0=c(rep(SD0[1:(length(SD0)-1)],each=2),SD0[length(SD0)])
x0T=c(tT0[1],rep(tT0[2:length(tT0)],each=2))
y0T=c(rep(ST0[1:(length(ST0)-1)],each=2),ST0[length(ST0)])



plot(NULL,xlim=c(0,20),ylim=c(0,1),frame=F,lwd=1.5, xlab="Time (months)",
     ylab="Survival probabilities",main="Usual Care")
polygon(c(x0,x0[length(x0)],0),c(y0,1,1),col='darkgray')
polygon(c(x0T,rev(x0),0),c(y0T,rev(y0),1),col='lightgray',border=F)
lines(x0,y0,lty=1)
lines(x0T,y0T,lty=3)
legend(0,0.2,lty=c(1,3),c("Death","TFE"))
}



#Cox PH
summary(coxph(Surv(time, status) ~ Training, data=data.TD))
summary(coxph(Surv(time, status>0) ~ Training, data=data.TFE))

#Cox PH on TFE adjusting for HF etiology
summary(coxph(Surv(time, status>0) ~ Training+HF.etiology, data=data.TFE))


#weighted proportional mean
Training=data[,"Training"]
HF.etiology=data[,"HF.etiology"]

#run the function CompoML to 
obj.ML=CompoML(id=id,time=time,status=status,Z=cbind(Training,HF.etiology),c(2,1))
obj.ML



# plot the model-based mean functions
par(mfrow=c(1,2))
#for non-ischemic
plot(obj.ML,c(0,0),ylim=c(0,2),xlim=c(0,20),main="Frequency of weighted (2:1) composite 
    endpoint in non-ischemic patients",  xlab="Time (months)",cex.main=1,col="red",lwd=2)
plot(obj.ML,c(1,0),lty=1,add=T,col="blue",lwd=2)
legend(0,2,col=c("red","blue"),c("Usual care","Exercise training"),lwd=2)
#for ischemic
plot(obj.ML,c(0,1),ylim=c(0,2),xlim=c(0,20),main="Frequency of weighted (2:1) composite 
    endpoint in ischemic patients", xlab="Time (months)",cex.main=1,col="red",lwd=2)
plot(obj.ML,c(1,1),lty=1,add=T,col="blue",lwd=2)
legend(0,2,col=c("red","blue"),c("Usual care","Exercise training"),lwd=2)

