
#replace this directory with the one of the unzipped files
setwd("")

# install rmt package
install.packages("./Code/rmt_1.0.tar.gz",repos = NULL, type = "source")
# or install directly from CRAN
# install.packages("rmt")
library(rmt)

####################################
## Analysis of colon cancer trial ##
####################################
head(colon_lev)
data_Lev4FU<-colon_lev
#### Descriptive analysis #####

# number of relapses
sum(data_Lev4FU$status==1)
# total number of death
sum(data_Lev4FU$status==2)

# number of relapse-free death
data_Lev4FU_TFE=data_Lev4FU[!duplicated(data_Lev4FU$id),]
sum(data_Lev4FU_TFE$status==2)

# number of death after relapse
sum(data_Lev4FU$status==2)-sum(data_Lev4FU_TFE$status==2)

dat1=data_Lev4FU[data_Lev4FU$rx=="Lev+5FU",]
dat0=data_Lev4FU[data_Lev4FU$rx=="Control",]

n1=length(unique(dat1$id)) # 304
n0=length(unique(dat0$id)) # 315
n=n1+n0

## Follow-up times ####
fut1=dat1[dat1$status!=1,"time"]
fut0=dat0[dat0$status!=1,"time"]

quantile(fut1) #5.7 years
quantile(fut0) # 5.1 years

median(c(fut1,fut0)) # 5.5 years
######################

# Event rates

#relapse rate
sum(dat1$status==1)/n1 #0.39
sum(dat0$status==1)/n0 #0.56


#death rate
sum(dat1$status==2)/n1 #0.40
sum(dat0$status==2)/n0 #0.53



#### formal analysis starts ######

# fit RMT-IF
obj<-rmtfit(ms(id,time,status)~rx,data=data_Lev4FU)
obj
# summary table for tau=7.5
rmt7_5<-summary(obj,7.5)$tab
rmt7_5
# bouquet plot
bouquet(obj)


### graphics#####
par(mfrow=c(1,2))

bouquet(obj,cex.group = 1.0,cex.lab=1.2,cex.axis=1.2,xlab="Restricted mean win/loss time (years)",
        ylab="Follow-up time (years)",group.label=F,ylim=c(0,8))
text(-1,7.95,paste("Control"),cex=1)
text(1,7.95,paste("Treatment"),cex=1)


plot(obj,conf=T,lwd=2, cex.lab=1.2,cex.axis=1.2,xlab="Follow-up time (years)",
     ylab="Restricted mean time in favor of treatment (years)",main="")
par(mfrow=c(1,1))
################


##################################
# RMT at tau=2.5, 5, and 7.5 years
##################################
rmt2_5=summary(obj,2.5)$tab
rmt5_0=summary(obj,5)$tab
rmt7_5=summary(obj,7.5)$tab

### format to LATEX table
za=qnorm(0.975)


pval_fmt3=function(x){
        if(x<0.001){
                return("$<$0.001")
        }else{
                return(round(x,3))
        }
}


ltable=NULL
for (i in 1:3){
        tmp=c("&&",round(12*rmt2_5[i,1],2),"&",round(12*rmt2_5[i,2],2),"&",pval_fmt3(rmt2_5[i,4]),
              "&&",round(12*rmt5_0[i,1],2),"&",round(12*rmt5_0[i,2],2),"&",pval_fmt3(rmt5_0[i,4]),
              "&&",round(12*rmt7_5[i,1],2),"&",round(12*rmt7_5[i,2],2),"&",pval_fmt3(rmt7_5[i,4]),"\\")
        ltable=rbind(ltable,tmp)
}

rownames(ltable)=c("Relapse","Death","Overall")

noquote(ltable)



### HF-ACTION analysis ###

##### Read in HF-ACTION DATA########

### recurrent event data######
data<-read.table("./Data/hf_action_nonischemic_cpx9.txt")

head(data)

uid=unique(data$patid)
n=length(uid)

uid1=unique(data$patid[data$trt_ab==1])
n1=length(uid1)

uid0=unique(data$patid[data$trt_ab==0])
n0=length(uid0)

# status=1: hosp; 2=death
data$status=3-data$status
data$status[data$status==3]=0
data$time=data$time/365

## average number of hosps

sum(data$status[data$trt_ab==1]==1)/n1
sum(data$status[data$trt_ab==0]==1)/n0

## total number of hosps
sum(data$status==1)
## total number of deaths
sum(data$status==2)

# fit RMT-IF
# obj=rmtfit(id,time,status,trt,type="recurrent")
obj<-rmtfit(rec(patid,time,status)~trt_ab,data=data)
summary(obj,Kmax=1,tau=3.98)


# graphics
par(mfrow=c(1,2))
bouquet(obj,Kmax=4,cex.group = 1.0,cex.lab=1.5,cex.axis=1.5,
        xlab="Restricted mean win/loss time (years)",
        ylab="Follow-up time (years)",group.label=F,ylim=c(0,4.2))
text(-0.8,4.15,paste("Usual care"),cex=1.2)
text(0.8,4.15,paste("Exercise training"),cex=1.2)

plot(obj,conf=T,lwd=2, cex.lab=1.5,cex.axis=1.5,xlab="Follow-up time (years)",
     ylab="RMT-IF of training (years)",main="")
par(mfrow=c(1,1))

### LaTeX table ###

### format to LATEX table

pval_fmt3=function(x){
        if(x<0.001){
                return("$<$0.001")
        }else{
                return(round(x,3))
        }
}

ltable=NULL
hosp_sum=summary(obj,Kmax=1,tau=3.98)$tab
all_sum=summary(obj,Kmax=4,tau=3.98)$tab

ltable=c("&","&","&",round(12*hosp_sum[1,1],2),"&",round(12*hosp_sum[1,2],2),"&",pval_fmt3(hosp_sum[1,4]),"\\")

for (i in 1:6){
        tmp=c("&",i,"&&",round(12*all_sum[i,1],2),"&",round(12*all_sum[i,2],2),"&",pval_fmt3(all_sum[i,4]),"\\")
        ltable=rbind(ltable,tmp)
}

ltable[5,2]="4+"
ltable[6:7,2]=""

rownames(ltable)=c("Hopitalization","","" ,"","","Death","Overall")
noquote(ltable)
