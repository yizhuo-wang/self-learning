
#######Run the preamble ###################################################
setwd("C://Users//Lu Mao//Desktop//Study//Files//Code//CE")
setwd("C://Users//lmao//Dropbox//Composite endpoints related work//Code//ML")
#replace this directory with the one of the unzipped files
source("compute.txt")
source("generic.txt")
###########################################################################


library(survival)

data=read.table("HF-ACTION.txt")

id=data[,1]
time=data[,2]
status=data[,3]
Z=as.matrix(data[,4:ncol(data)])

obj1=CompoML(id,time,status,Z,c(2,1,1),ep=1e-4)
obj2=CompoML(id,time,status,Z,c(3,2,1),ep=1e-4)


obj1
obj2

par(mfrow=c(1,2))
plot(obj1,c(0,0),ylim=c(0,7),xlim=c(0,35),main="Death: 2; HF: 1; Hosp: 1",
     xlab="Time (months)",cex.main=1)
plot(obj1,c(1,0),lty=3,add=T)

plot(obj2,c(0,0),ylim=c(0,7),xlim=c(0,35),main="Death: 3; HF: 2; Hosp: 1",
     xlab="Time (months)",cex.main=1)
plot(obj2,c(1,0),lty=3,add=T)




