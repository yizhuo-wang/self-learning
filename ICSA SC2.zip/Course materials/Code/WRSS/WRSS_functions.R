

###########################################################################
#               General win-ratio analysis function                     ###
###########################################################################

####################WR.anal###############################################
# Input:
# dat1: n1 x p matrix (trt data)
# dat0: n0 x p matrix (control data)
# winfun: win function taking on two p-dimensional
# vecotrs y1, y0 and returning
#     1 if y1 wins
#    -1 if y0 wins
#     0 if indeterminate
#
# Output:
# log.WR: log-win ratio
# se: estimated standard error of log.WR
###########################################################################

WR.anal=function(dat1,dat0,winfun){
  dat1=as.matrix(dat1)
  dat0=as.matrix(dat0)

  n1=nrow(dat1)
  n0=nrow(dat0)

  # win-loss matrix
  # WL_ij=I(Y_1i\succ Y_0j)-I(Y_0j\succ Y_1i)
  WL=matrix(0,n1,n0)

  for (i in 1:n1){
    y1=dat1[i,]
    for (j in 1:n0){
      y0=dat0[j,]
      r=winfun(y1,y0) #r=I(y1\succ y0)-I(y0\succ y1)
      WL[i,j]=r
    }
  }
  win.mat=(WL==1)
  loss.mat=(WL==-1)
  #win-loss probabilities
  theta1=mean(win.mat)
  theta0=mean(loss.mat)
  theta=c(theta1,theta0)

  #influence functions for win-loss probabilities
  #of treatment and control arms
  w1=cbind(rowMeans(win.mat)-theta1,rowMeans(loss.mat)-theta0)#n1 x 2
  w0=cbind(colMeans(win.mat)-theta1,colMeans(loss.mat)-theta0)#n0 x 2
  #colMeans(w1): should be c(0,0)

  #variance of the win-loss estimators
  Sigma=n1^{-2}*t(w1)%*%w1+n0^{-2}*t(w0)%*%w0

  #compute the log-win ratio and its
  #standard error


  #log-win ratio
  log.WR=log(theta[1]/theta[2])

  #derivative of log-WR
  f=c(1/theta[1],-1/theta[2])

  #standard error of log-win ratio
  # by delta method
  se=sqrt(t(f)%*%Sigma%*%f)

  return(list(log.WR=log.WR,se=se,wl=theta))


}


#===========================================================================================#
#===========================================================================================#


########################################################################
#             Functions for Ordinal outcomes                          ##
########################################################################


############sample size function##WRSS.ord()######################################
# Description: sample size formula for ordinal outcomes under proportional odds model
#
# Input:
# xi: a vector of log-odds ratios (effect size)
# pi0: baseline probabilities for Y_0=1,...,m-1 (control group)
#       pr(Y_0=m)=1-sum(pi0)
# q: sample size proportion
WRSS.ord=function(xi,pi0,q=0.5,alpha=0.05,side=2,power=0.8){

  pi0=c(pi0,1-sum(pi0))
  if (any(pi0<=0)){
    cat("The elements of pi0 must be strictly positive and their sum must be strictly
        less than one!")
    return(1)
  }
  m=length(pi0)
  W=rep(0,m)

  for (k in 1:(m-1)){
      W[k]=sum(pi0[(k+1):m])
  }

  L=1-pi0-W

  zeta2=sum(pi0*(W-L)^2)
  delta=sum(pi0*(2*W*L+pi0*(1-pi0)))

  eta2=zeta2/delta^2

  #sample size formula
  za=qnorm(1-alpha/side)
  zb=qnorm(power)

  n=eta2*(za+zb)^2/(q*(1-q)*xi^2)
  return(list(eta2=eta2,n=n,xi=xi))

}


###############################################################
# Win function for ordinal outcomes
# see argument "winfun" in WR.anal()
#############################################################
win.ord=function(y1,y2){
  return((y1>y2)-(y1<y2))
}


############################################################
# Generate multinomial probabilities in the trt group pi0
# based on control group probabilities and log-odds ratio xi
# (used in simulating data)
############################################################
pi1.fun=function(pi0,xi){

  m=length(pi0)+1
  L0=rep(0,m)
  L1=rep(0,m)
  pi1=rep(0,m-1)

  # under proportional odds exp(xi):
  #L_1k=1/(exp(xi)*(1/L_0k-1)+1)

  for (k in 2:m){
  L0[k]=sum(pi0[1:(k-1)])
  L1[k]=1/(exp(xi)*(1/L0[k]-1)+1)
  pi1[k-1]=L1[k]-L1[k-1]
  }

return(pi1)

}


##############################################################
# Simulate a vector of size n
# Each element Y_i follows pr(Y_i=k)=pi[k] (k=1,...m-1)
# where m=length(pi) and
# pr(Y_i=m)=1-sum_{k=1}^{m-1}pi[k]
# The probabilities must lie in (0, 1)
# (used in simulating data)
##############################################################
rord=function(n,pi){
  obj=rmultinom(n=n, size=1, prob=c(pi,1-sum(pi)))
  m=length(pi)+1
  dat=rep(0,n)
 for (k in 1:m){
   dat=dat+k*obj[k,]
 }


 return(dat)

}

##############################################
# Ordinal outcomes simulation function
############################################
# Input variables
# N: number of replicates
# n: total sample size
# 0<q<1: proportion assigned to treatment
# alpha: type I error
# side: 2- or 1-sided test
# pi0: baseline probabilities
# xi: log-odds ratio under proportional odds model
# (simulated data \in {1, 2,...,m}, where m=length(pi0)+1)
#
# Output: empirical power
##########################################################
ord.simulate=function(N,n,q,pi0,xi,alpha=0.05,side=2){

  rej=rep(NA,N)
  za=qnorm(1-alpha/side)#critical value
  for (j in 1:N){
    n1=round(n*q)
    n0=n-n1

    #trt level probabilities
    pi1=pi1.fun(pi0,xi)

    #simulate data
    dat0=rord(n0,pi0)
    dat1=rord(n1,pi1)

    #WR analysis
    obj=WR.anal(dat1,dat0,win.ord)
    if (side==2){
      rej[j]=(abs(obj$log.WR/obj$se)>za)
    }else{
      rej[j]=(obj$log.WR/obj$se>za)
    }


    cat(j,mean(rej,na.rm=T),"\n")
  }

  return(mean(rej,na.rm=T))

}



#===========================================================================================#
#===========================================================================================#


########################################################################
#             Functions for bivariate normal outcomes                 ##
########################################################################
############sample size function##WRSS.binorm()######################################
# Description: sample size formula for bivariate normal outcomes
#
# Input:
# xi: a matrix whose columns are bivariate location shift (effect size)
#
# rho: correlation parameter
# q: sample size proportion
WRSS.binorm=function(xi,rho,q=0.5,alpha=0.05,side=2,power=0.8){

  xi=as.matrix(xi)
  #sample size formula
  za=qnorm(1-alpha/side)
  zb=qnorm(power)

  n=2*(pi+6*asin(rho/2))*(za+zb)^2/(3*q*(1-q)*colSums(xi)^2)

  return(list(rho=rho,n=n,xi=xi))

}


###############################################################
# Win function for multivariate outcomes
# see argument "winfun" in WR.anal()
#############################################################
win.mul=function(y1,y2){
  return(all(y1>y2)-all(y1<y2))
}




#===========================================================================================#
#===========================================================================================#


########################################################################
#             Functions for composite outcomes (under Gumbel model)   ##
########################################################################

# The delta function using numerical integration
# the output is a vector of (delta_1,delta_2)
library(cubature)
library(gumbel)

delta.fun = function(baseline){
  lambda_D=baseline$lambda_D
  lambda_H=baseline$lambda_H
  kappa=baseline$kappa
  tau_c=baseline$tau_c
  tau=baseline$tau
  lambda_L=baseline$lambda_L

  # the input "x" is a vector containing two entries (s,t)
  SD = function(x){
    exp(-lambda_D*x[2])
  }

  g_tilde = function(x){
    if(x[1] > tau - tau_c){
      2/tau_c^2*exp(-2*lambda_L*x[1])*(tau-x[1])*(lambda_L*(tau-x[1])+1)
    }else{
      2*lambda_L*exp(-2*lambda_L*x[1])
    }
  }
  delta1 = adaptIntegrate(function(x){
    tem = ((lambda_D*x[1])^kappa+
             (lambda_H*x[2])^kappa)^(1/kappa)
    H0 = exp(-tem)
    lambda1= tem^(1-2*kappa)*(1-kappa)*(lambda_D*lambda_H*x[1])^kappa*x[2]^(kappa-1)

    return(ifelse(x[2]<=x[1],1,0)*(lambda_D*SD(x)^2 + H0^2*lambda1)*g_tilde(x))
  },
  c(0,0), c(tau,tau))

  delta2 = adaptIntegrate(function(x){
    tem = ((lambda_D*x[1])^kappa+
             (lambda_H*x[2])^kappa)^(1/kappa)
    H0 = exp(-tem)
    lambda2 =  (1-kappa)*tem^(1-2*kappa) *
      (lambda_H)^(2*kappa)*x[2]^(2*kappa-1)+
      kappa * tem^(1-kappa) *
      x[2]^(kappa-1)*lambda_H^kappa

    return(ifelse(x[2]<=x[1],1,0) * (H0^2*lambda2)*g_tilde(x))
  },
  c(0,0), c(tau,tau))

  return(c(delta1 = delta1$integral,delta2 = delta2$integral))
}





###############################################################
# Win function for composite outcomes
# see argument "winfun" in WR.anal()
#############################################################
Wp = function(y1,y2){
  ifelse(y2[1]<min(c(y1[1],y1[3],y2[3])),1,0) +
    ifelse((min(c(y1[1],y2[1])) > min(c(y1[3], y2[3])) ) &
             (y2[2] < min(c(y1[2],y1[3],y2[3]))),1,0)
}

## This is the win-loss difference function
win.comp = function(y1,y2){Wp(y1,y2) - Wp(y2,y1)}

# monte-carlo integration of zeta_0^2
zeta2.fun=function(baseline,N=2000,seed){


  lambda_D=baseline$lambda_D
  lambda_H=baseline$lambda_H
  kappa=baseline$kappa
  tau_c=baseline$tau_c
  tau=baseline$tau
  lambda_L=baseline$lambda_L


  #simulate death, hosp, and cenosring
  # Death
  set.seed(seed)
  outcome=rgumbel(N,alpha=kappa,dim=2)
  D=-log(outcome[,1])/lambda_D
  H=-log(outcome[,2])/lambda_H
  set.seed(seed)
  Ca=tau_c*runif(N)+tau-tau_c
  set.seed(seed)
  L=rexp(N)/lambda_L
  C=pmin(Ca,L)



  dat=cbind(D,H,C)

  tmp=combn(1:nrow(dat),2,function(x) win.comp(dat[x[1],],dat[x[2],]))



  WL.matrix=matrix(0,N,N)

  WL.matrix[lower.tri(WL.matrix)]=tmp

  WL.matrix=t(WL.matrix)-WL.matrix

  w0=sum(abs(WL.matrix))/(2*N*(N-1))
  ranks=rowSums(WL.matrix)/(N-1)
  zeta2=sum(ranks^2)/(N-3)

  return(list(w0=w0,zeta2=zeta2))


}

#######################################################
# Function to compute the baseline parameters
# in the sample size formula of Pocock's win ratio
######################################################

base=function(lambda_D,lambda_H,kappa,tau_c,tau,lambda_L,N=1000,seed=12345){
  baseline=list(lambda_D=lambda_D,lambda_H=lambda_H,kappa=kappa,tau_c=tau_c,
                tau=tau,lambda_L=lambda_L)

  obj=zeta2.fun(baseline,N,seed)
  zeta2=obj$zeta2
  w0=obj$w0

  # to be conservative, use another monte-carlo
  # integration to compute zeta2 and take maximum
  obj1=zeta2.fun(baseline,N,seed+1)
  zeta2=max(zeta2,obj1$zeta2)

  delta=delta.fun(baseline)

  return(list(zeta2=zeta2,w0=w0,delta=delta))

}



############sample size function##WRSS.comp()######################################
# Description: sample size formula for bivariate normal outcomes
#
# Input:
# xi: a bivariate vector of log-HRs (effect size)
# rho: correlation parameter
# q: sample size proportion
WRSS.comp=function(xi,bparam,q=0.5,alpha=0.05,side=2,power=0.8){

  xi=as.matrix(xi)
  #sample size formula
  za=qnorm(1-alpha/side)
  zb=qnorm(power)

  zeta2=bparam$zeta2
  w0=bparam$w0
  delta=bparam$delta

  n=zeta2*(za+zb)^2/(q*(1-q)*(t(xi)%*%delta)^2)

  return(list(zeta2=zeta2,delta=delta,w0=w0,n=n,xi=xi))

}



#===========================================================================================
# Estimating the baseline parameters lambda_D, lambda_H
# and kappa from pilot study data
#===========================================================================================
gumbel.est=function(id, time, status){
  
  data=as.data.frame(cbind(id,time,status))
  #Sort the data by time within each id
  o=order(data$id,data$time)
  data=data[o,]
  
  ######################################
  #Composite (time-to-first) event rate#
  ######################################
  #subset to first event data
  #Sort the data by time within each id
  
  # get the first row for each id
  data.CE=data[!duplicated(data$id),]
  # event rate
  lambda_CE=sum(data.CE$status>0)/sum(data.CE$time)
  #########################################
  # Cause-specific hazard rate for hosp
  ##########################################
  lambda_sH=sum(data.CE$status==2)/sum(data.CE$time)
  
  
  ######################
  #     Death rate    ##
  ######################
  data.D=data[data$status<2,]
  # event rate
  lambda_D=sum(data.D$status)/sum(data.D$time)
  
  
  
  
  kappa=log(1-lambda_sH/lambda_CE)/log(lambda_D/lambda_CE)
  
  lambda_H=(lambda_CE^kappa-lambda_D^kappa)^(1/kappa)
  
  return(list(lambda_D=lambda_D,lambda_H=lambda_H,kappa=kappa))
  
}


