
#replace this directory with the one of the unzipped files
setwd("")


#################################################################
#                       Recurrent-event win ratio test          #
#################################################################

#Complile the source code for the function WRrec

source("./Code/WRrec/WRrec_functions.R")

library(survival)


##### Read in HF-ACTION DATA########

### recurrent event data######
data<-read.table("./Data/hf_action_nonischemic_cpx9.txt")

## data including only first hospitalization (for Pocock's win ratio (SWR))
data.H1<-read.table("./Data/hf_action_nonischemic_cpx9_H1.txt")


head(data)

############ number of patients per group #####
uid=unique(data$patid)
n=length(uid)

uid1=unique(data$patid[data$trt_ab==1])
n1=length(uid1)

uid0=unique(data$patid[data$trt_ab==0])
n0=length(uid0)

#### demo ############

obj<-WRrec(ID=data$patid,time=data$time,status=data$status,
      trt=data$trt_ab,strata=data$age60,naive=T)
# LWR
beta<-obj$log.WR
se<-obj$se
# test
pval<-2*(1-pnorm(abs(beta/se)))
pval

# NWR
beta.naive<-obj$log.WR.naive
se.naive<-obj$se.naive
# test
pval.naive<-2*(1-pnorm(abs(beta.naive/se.naive)))
pval.naive


# FWR
beta.FI<-obj$log.WR.FI
se.FI<-obj$se.FI
# test
pval.FI<-2*(1-pnorm(abs(beta.FI/se.FI)))
pval.FI
#################################
# Win ratio analyses: tabulate  #
#################################

gwr.fun=function(ind,ind1,r=2){

obj=WRrec(ID=data$patid[ind],time=data$time[ind],status=data$status[ind],
          trt=data$trt_ab[ind],strata=data$age60[ind],naive=T)
obj1=WRrec(ID=data.H1$patid[ind1],time=data.H1$time[ind1],status=data.H1$status[ind1],
          trt=data.H1$trt_ab[ind1],strata=data.H1$age60[ind1],naive=F)




za=qnorm(0.975)


beta=obj$log.WR
se=obj$se
theta=obj$theta

r4=c(paste0(round(100*theta[1],1),"%"),
     paste0(round(100*theta[2],1),"%"),
     paste0(round(exp(beta),r)," (",round(exp(beta-za*se),r),", ",round(exp(beta+za*se),r),")"),
     round(1-pchisq((beta/se)^2,1),3)
)



beta1=obj1$log.WR
se1=obj1$se
theta1=obj1$theta

r1=c(paste0(round(100*theta1[1],1),"%"),
     paste0(round(100*theta1[2],1),"%"),
     paste0(round(exp(beta1),r)," (",round(exp(beta1-za*se1),r),", ",round(exp(beta1+za*se1),r),")"),
     round(1-pchisq((beta1/se1)^2,1),3)
)


beta.naive=obj$log.WR.naive
se.naive=obj$se.naive
theta.naive=obj$theta.naive


r2=c(paste0(round(100*theta.naive[1],1),"%"),
     paste0(round(100*theta.naive[2],1),"%"),
     paste0(round(exp(beta.naive),r)," (",round(exp(beta.naive-za*se.naive),r),", ",
            round(exp(beta.naive+za*se.naive),r),")"),
     round(1-pchisq((beta.naive/se.naive)^2,1),3)
)





beta.FI=obj$log.WR.FI
se.FI=obj$se.FI
theta.FI=obj$theta.FI


r3=c(paste0(round(100*theta.FI[1],1),"%"),
     paste0(round(100*theta.FI[2],1),"%"),
     paste0(round(exp(beta.FI),r)," (",round(exp(beta.FI-za*se.FI),r),", ",
            round(exp(beta.FI+za*se.FI),r),")"),
     round(1-pchisq((beta.FI/se.FI)^2,1),3)
)

result=rbind(r1,r2,r3,r4)
rownames(result)=c("PWR","NWR","FWR","LWR")

return(result)
}

ind=(data$age60==0)
ind1=(data.H1$age60==0)

result.lt60=gwr.fun(ind,ind1,r=2)

ind=(data$age60==1)
ind1=(data.H1$age60==1)

result.ge60=gwr.fun(ind,ind1,r=2)

ind=rep(T,nrow(data))
ind1=rep(T,nrow(data.H1))

result.all=gwr.fun(ind,ind1,r=2)

results=rbind(result.lt60,result.ge60,result.all)

colnames(results)=c("Win", "Loss", "Win ratio (95% CI)", "p-value")

noquote(results)



############################################################################
#               Sample size calculation                                    #     
############################################################################

source("./Code/WRSS/WRSS_functions.R")

#===============================================#
#      Real data: ACCORD trial                  #
#===============================================#
# Read in pilot data
outcome.sBP=read.csv("./Data/ACCORD_BP.csv",header=T)
head(outcome.sBP)
outcome.sBP[1:6,c("MaskID","treatment", "time","status")]

############## estimate parameters ##############

# Get the variables from pilot dataset
# to estimate baseline parameters 
# lambda_D, lambda_H, kappa
id<-outcome.sBP[,"MaskID"]
time<-as.numeric(outcome.sBP[,"time"])
status<-as.numeric(outcome.sBP[,"status"])
n<-length(unique(id))
# use the gumbel.est() function
obj_base<-gumbel.est(id, time, status)

lambda_D<-obj_base$lambda_D
lambda_H<-obj_base$lambda_H
kappa<-obj_base$kappa


lambda_D
lambda_H
kappa

### demo ###################

# set design parameters
tau_c<-3.5
tau<-7
lambda_L=0.001
# use base() function to compute zeta2 and delta
bparam<-base(lambda_D,lambda_H,kappa,tau_c,tau,lambda_L)
# compute sample size under HRs 0.9 and 0.8
# for death and nonfatal event, respectively
obj<-WRSS.comp(xi=log(c(0.9,0.8)),bparam=bparam,q=0.5,alpha=0.05,
          power=0.8)

obj$n


#### Generate figure ###############
# design parameters
tau.list=c(7,10)
tau_c.list=tau.list/2
lambda_L=0.001

# compute baseline parameters under tau=7 and 10 years
bparam1=base(lambda_D,lambda_H,kappa,tau_c.list[1],tau.list[1],lambda_L,N=1000)
bparam2=base(lambda_D,lambda_H,kappa,tau_c.list[2],tau.list[2],lambda_L,N=1000)
bparam.list=list(bparam1,bparam2)

##### plot the sample sizes#######
m=30
hr1 <- seq(0.6, 0.9, length= m)
hr2 <- seq(0.6, 0.9, length= m)

power.list=c(0.8,0.9)

par(mfcol=c(2,2))
par(mar=c(4,2,2,1))

for (p in 1:2){
        power=power.list[p]
        
        for (l in 1:2){
                bparam=bparam.list[[l]]
                
                
                
                z=matrix(NA,m,m)
                for (i in 1:m){
                        x=hr1[i]
                        for (j in 1:m){
                                y=hr2[j]
                                obj.n=WRSS.comp(xi=log(c(x,y)),bparam=bparam,q=0.5,alpha=0.05,
                                                power=power)
                                z[i,j]=obj.n$n/1000
                        }
                        
                }
                
                persp(hr1, hr2, z, theta = 50, phi = 15, expand = 0.8, col = "gray",
                      ltheta = 180, lphi=180, shade = 0.75, 
                      ticktype = "detailed",
                      xlab = "\nHR on CV Death", ylab = "\nHR on MI/Stroke", 
                      zlab=paste0("\n Sample Size (10e3)"), 
                      main=paste0("Power=",power,"\n Max ",
                                  7+3*(l-1),"-year follow-up"),
                      zlim=c(0,40),cex.axis=1,cex.lab=1.2,cex.main=1.2
                )
                
                
        }
}



